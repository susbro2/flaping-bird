import pygame
import random
import sys

# Initialize Pygame
pygame.init()

# Screen dimensions
WIDTH = 800
HEIGHT = 600
FPS = 60

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)
GREEN = (0, 255, 0)

# Bird settings
BIRD_WIDTH = 50
BIRD_HEIGHT = 50
UPWARD_THRUST = -8
GRAVITY = 0.5

# Coin settings
COIN_WIDTH = 20
COIN_HEIGHT = 20
COIN_SPEED = 5

# Barrier settings
BARRIER_WIDTH = 70
BARRIER_HEIGHT = 200
BARRIER_SPEED_X = 5
BARRIER_SPEED_Y = 3

# Initialize screen
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Bird Game")

# Clock
clock = pygame.time.Clock()

# Font for score
font = pygame.font.SysFont("Arial", 30)

# Function to display text
def draw_text(text, x, y, color):
    label = font.render(text, True, color)
    screen.blit(label, (x, y))

# Bird class
class Bird(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((BIRD_WIDTH, BIRD_HEIGHT))
        self.image.fill(RED)  # Player bird is red
        self.rect = self.image.get_rect()
        self.rect.center = (100, HEIGHT // 2)
        self.velocity = 0

    def update(self, mouse_held=False):
        # If mouse is held, apply upward thrust
        if mouse_held:
            self.velocity = UPWARD_THRUST
        else:
            # Apply gravity
            self.velocity += GRAVITY

        # Update position
        self.rect.y += self.velocity

        # Prevent bird from going off-screen
        if self.rect.top < 0:
            self.rect.top = 0
            self.velocity = 0
        if self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT
            self.velocity = 0
# Coin class
class Coin(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((COIN_WIDTH, COIN_HEIGHT))
        self.image.fill(YELLOW)  # Coin is yellow
        self.rect = self.image.get_rect()
        self.rect.x = WIDTH
        self.rect.y = random.randint(50, HEIGHT - 50)

    def update(self):
        self.rect.x -= COIN_SPEED
        if self.rect.right < 0:
            self.kill()

# Moveable Barrier class
class MoveableBarrier(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((BARRIER_WIDTH, BARRIER_HEIGHT))
        self.image.fill(GREEN)  # Barrier is green
        self.rect = self.image.get_rect()
        self.rect.x = WIDTH
        self.rect.y = random.randint(0, HEIGHT - BARRIER_HEIGHT)
        self.speed_y = random.choice([-BARRIER_SPEED_Y, BARRIER_SPEED_Y])
        self.oscillation_range = random.randint(20, 100)  # Unique oscillation range
        self.initial_y = self.rect.y

    def update(self):
        # Move horizontally
        self.rect.x -= BARRIER_SPEED_X
        # Move vertically
        self.rect.y += self.speed_y
        # Reverse direction if it hits the top or bottom of the screen
        if self.rect.top <= 0 or self.rect.bottom >= HEIGHT:
            self.speed_y = -self.speed_y
        # Add oscillation effect
        if abs(self.rect.y - self.initial_y) > self.oscillation_range:
            self.speed_y = -self.speed_y
# Main game loop
def main():
    # Sprite groups
    all_sprites = pygame.sprite.Group()
    coins = pygame.sprite.Group()
    barriers = pygame.sprite.Group()

    # Create bird
    bird = Bird()
    all_sprites.add(bird)

    # Score
    score = 0

    # Timers for coin and barrier spawn
    COIN_TIMER = pygame.USEREVENT + 1
    pygame.time.set_timer(COIN_TIMER, 600)  # New coin every 600 milliseconds

    BARRIER_TIMER = pygame.USEREVENT + 2
    pygame.time.set_timer(BARRIER_TIMER, 1200)  # New barrier every 1.2 seconds

    # Game loop
    running = True
    mouse_held = False  # Tracks if the mouse button is held down
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                mouse_held = True
            if event.type == pygame.MOUSEBUTTONUP:
                mouse_held = False
            if event.type == COIN_TIMER:
                # Spawn a new coin
                coin = Coin()
                all_sprites.add(coin)
                coins.add(coin)
            if event.type == BARRIER_TIMER:
                # Spawn a new moveable barrier
                barrier = MoveableBarrier()
                all_sprites.add(barrier)
                barriers.add(barrier)

        # Update bird with mouse control
        bird.update(mouse_held)

        # Update other sprites
        coins.update()
        barriers.update()

        # Check collision with coins
        coin_hits = pygame.sprite.spritecollide(bird, coins, True)
        for coin in coin_hits:
            score += 1

        # Check collision with barriers
        if pygame.sprite.spritecollideany(bird, barriers):
            print("Game Over!")
            running = False

        # Draw
        screen.fill(WHITE)
        all_sprites.draw(screen)
        draw_text(f"Score: {score}", 10, 10, BLACK)

        # Update display
        pygame.display.flip()

        # Set FPS
        clock.tick(FPS)

    print(f"Final Score: {score}")
    pygame.quit()

# Run the game
if __name__ == "__main__":
    main()
